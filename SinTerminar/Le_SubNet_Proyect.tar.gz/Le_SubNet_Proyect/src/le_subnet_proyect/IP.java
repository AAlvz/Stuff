/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package le_subnet_proyect;

/**
 *
 * @author alfonso
 */
public class IP {
    public int c1, c2, c3, c4, smk;
    
    public IP(int c1, int c2, int c3, int c4, int smk)
    {
        this.c1 = c1;
        this.c2 = c2;
        this.c3 = c3;
        this.c4 = c4;
        this.smk = smk;
        
    }
}
